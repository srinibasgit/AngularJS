var m = angular.module("mymod");
m.controller("mycontroller", function($scope) {
	console.log("my controller constructor invoked ...")
	$scope.mynm = "aaa";
});
m.controller("lab31", function($scope) {
	console.log("lab31 constructor invoked ...")
	$scope.name = "Sim";
	$scope.age = 20;
});
m.controller("lab32", function($scope) {
	console.log("lab32 constructor invoked ...")
	$scope.name = "Sim111";
});