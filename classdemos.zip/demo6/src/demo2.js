	var mymodvar = angular.module("mymod", []);
	mymodvar.controller("mycontroller", function($scope) {
		$scope.nmarr = [];
		$scope.addfr = function() {
			$scope.nmarr.push($scope.mynm);
		}
	});
