function add(i, j)
{
	return (i+j);
}