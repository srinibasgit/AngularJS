describe("Demo1TestSuite", function() {

  beforeEach(function() {
	  console.log("before each");
  });

  it("add with both int param", function() {
    expect(add(10,20)).toEqual(30);
  });

  it("add with both double param", function() {
	    expect(add(10.20,20.02)).toEqual(30.22);
	  });

  it("add with both string param", function() {
	    expect(add("A","B")).toEqual("AB");
	  });
	 });  