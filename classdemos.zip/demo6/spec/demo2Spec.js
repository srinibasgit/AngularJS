describe('MyController Testing', function() {
  beforeEach(angular.mock.module('mymod'));

  var $controller, $rootScope;

  beforeEach(inject(function(_$controller_, _$rootScope_){
    // The injector unwraps the underscores (_) from around the parameter names when matching
    $controller = _$controller_;
    $rootScope = _$rootScope_;
  }));

  describe('addfriend Test 1', function() {
    it('adding a friend to empty list', function() {
      var $scope = $rootScope.$new();
      var controller = $controller('mycontroller', { $scope: $scope });
      $scope.mynm="AA";
      $scope.addfr();
      expect($scope.nmarr.length).toEqual(1);
    });
  });
  describe('addfriend Test 2', function() {
	    it('adding a friend to empty list', function() {
	      var $scope = $rootScope.$new();
	      var controller = $controller('mycontroller', { $scope: $scope });
	      $scope.mynm="AA";
	      $scope.nmarr=["aa","bb","cc"];
	      $scope.addfr();
	      expect($scope.nmarr.length).toEqual(4);
	    });
	  });
  
});